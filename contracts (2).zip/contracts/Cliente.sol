// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract Cliente {
    
    // Estructura de datos para un cliente
    struct ClienteData {
        address dirCliente;
        address direccionE;
        string nombre;
    }
    
    // Mapeo de address a datos de cliente
    mapping(address => ClienteData) public clientes;
    
    // Array para almacenar todas las direcciones de clientes
    address[] public direccionesClientes;
    
    // Eventos para notificar cambios
    event ClienteAgregado(address indexed dirCliente, address indexed direccionE, string nombre);
    
    // Función optimizada con Yul para agregar cliente
    function agregarCliente(address _dirEmpresa, string memory _nombre) public {
        require(bytes(_nombre).length > 0, "El nombre no puede estar vacio");
        
        // Verificar si el cliente ya existe para evitar duplicados
        require(clientes[msg.sender].dirCliente == address(0), "La empresa ya existe.");
        
        // Guardar el nuevo cliente en el mapeo
        clientes[msg.sender] = ClienteData({
            dirCliente: msg.sender,
            direccionE: _dirEmpresa,
            nombre: _nombre
        });
        
        // Agregar la dirección a la lista de direcciones
        direccionesClientes.push(msg.sender);
        
        // Emitir evento
        emit ClienteAgregado(msg.sender, _dirEmpresa, _nombre);
    }
    
    // Función para consultar un cliente
    function consultarCliente(address _dirCliente) public view returns (string memory, address) {
        require(clientes[_dirCliente].dirCliente != address(0), "La empresa no existe.");
        return (clientes[_dirCliente].nombre, clientes[_dirCliente].direccionE) ;
    }
    
// Función para consultar todas los clientes
    function consultarTodasLosClientes() public view returns (address[] memory, address[] memory, string[] memory) {
        uint256 totalClientes = direccionesClientes.length;
        
        address[] memory _dirCliente = new address[](totalClientes);
        address[] memory _dirEmpresa = new address[](totalClientes);
        string[] memory _nombres = new string[](totalClientes);
        
        for (uint i = 0; i < totalClientes; i++) {
            address dir = direccionesClientes[i];
            _dirCliente[i] = dir;
            _dirEmpresa[i] = clientes[dir].direccionE;
            _nombres[i] = clientes[dir].nombre;
        }
        
        return (_dirCliente, _dirEmpresa, _nombres);
    }}
