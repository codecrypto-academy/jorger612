// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract Empresa2 {
    
    // Estructura de datos para una empresa
    struct EmpresaData {
        address direccion;
        string nombre;
    }
    
    // Mapeo de address a datos de empresa
    mapping(address => EmpresaData) public empresas;
    
    // Array para almacenar todas las direcciones de empresas
    address[] public direccionesEmpresas;
    
    // Eventos para notificar cambios
    event EmpresaAgregada(address indexed direccion, string nombre);
    
    // Función optimizada con Yul para agregar empresa
    function agregarEmpresa(string memory _nombre) public {
        require(bytes(_nombre).length > 0, "El nombre no puede estar vacio");
        
        // Verificar si la empresa ya existe para evitar duplicados
        require(empresas[msg.sender].direccion == address(0), "La empresa ya existe.");
        
        // Guardar la nueva empresa en el mapeo
        empresas[msg.sender] = EmpresaData({
            direccion: msg.sender,
            nombre: _nombre
        });
        
        // Agregar la dirección a la lista de direcciones
        direccionesEmpresas.push(msg.sender);
        
        // Emitir evento
        emit EmpresaAgregada(msg.sender, _nombre);
    }
    
    // Función para consultar una empresa
    function consultarEmpresa(address _direccion) public view returns (string memory) {
        require(empresas[_direccion].direccion != address(0), "La empresa no existe.");
        return empresas[_direccion].nombre;
    }
    
    // Función para consultar todas las empresas
    function consultarTodasLasEmpresas() public view returns (address[] memory, string[] memory) {
        uint256 totalEmpresas = direccionesEmpresas.length;
        
        address[] memory _direcciones = new address[](totalEmpresas);
        string[] memory _nombres = new string[](totalEmpresas);
        
        for (uint i = 0; i < totalEmpresas; i++) {
            address dir = direccionesEmpresas[i];
            _direcciones[i] = dir;
            _nombres[i] = empresas[dir].nombre;
        }
        
        return (_direcciones, _nombres);
    }
}
