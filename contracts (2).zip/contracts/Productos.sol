// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract Productos {
    
    // Estructura de datos para un producto
    // Un producto queda definido por un AddressEmpresa, Id, Nombre, Precio, Imagen 
    struct ProductoData {
        uint256 idProducto;
        address dirEmpresa;
        string nombre;
        uint256 precio;
        string pathImagen;
    }
    
    uint private idProd = 0;

    
    // Mapeo de address a datos de cliente
    mapping(uint256 => ProductoData) public productos;
    
    // Array para almacenar todos los productos
    uint256[] public identificadorProductos;
    
    // Eventos para notificar cambios
    event ProductoAgregado(uint256 indexed idProducto, address indexed dirEmpresa, string nombre, uint256 precio, string pathImagen);
    // Función optimizada con Yul para agregar cliente
    function agregarProducto(address _dirEmpresa, string memory _nombre, uint _precio, string memory _pathImagen) public {
        require(bytes(_nombre).length > 0, "El nombre no puede estar vacio");
                
        // Guardar el nuevo producto en el mapeo
        productos[idProd] = ProductoData({
            idProducto: idProd,
            dirEmpresa: _dirEmpresa,
            nombre: _nombre,
            precio: _precio,
            pathImagen: _pathImagen
        });
        

        // Agregar el ID a la lista de productos
        identificadorProductos.push(idProd);
        idProd++;
        // Emitir evento
        emit ProductoAgregado(idProd, _dirEmpresa, _nombre, _precio, _pathImagen);
    }
    
    // Función para consultar un Producto
    /*function consultarProducto(address _dirCliente) public view returns (string memory, address) {
        require(clientes[_dirCliente].dirCliente != address(0), "La empresa no existe.");
        return (clientes[_dirCliente].nombre, clientes[_dirCliente].direccionE) ;
    }*/
    
// Función para consultar todos los Productos
    function consultarTodosLosProductos() public view returns (uint256[] memory, address[] memory, string[] memory, uint256[] memory, string[] memory) {
        uint256 totalProductos = identificadorProductos.length;
        
        uint256[] memory _idProd = new uint256[](totalProductos);
        address[] memory _dirEmpresa = new address[](totalProductos);
        string[] memory _nombres = new string[](totalProductos);
        uint256[] memory _precio = new uint256[](totalProductos);
        string[] memory _pathImagen = new string[](totalProductos);



        
        for (uint i = 0; i < totalProductos; i++) {
            uint256 idProd = identificadorProductos[i];
            _idProd[i] = idProd;
            _dirEmpresa[i] = productos[idProd].dirEmpresa;
            _nombres[i] = productos[idProd].nombre;
            _precio[i] = productos[idProd].precio;
            _pathImagen[i] = productos[idProd].pathImagen;
        }
        
        return (_idProd, _dirEmpresa, _nombres, _precio, _pathImagen);
    }
}