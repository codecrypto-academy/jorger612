// SPDX-License-Identifier: MIT
pragma solidity >=0.7.0 <0.9.0;

import "./SafeMath.sol";

contract OverflowUnderflowExample{
    using SafeMath for uint8;
    function overflowExample(uint8 _val) public pure returns (uint8){
        uint8 maxValue = 255;
        maxValue = uint8(maxValue.add(_val));
        return maxValue;
    }
    function underflowExample(uint8 _val) public pure returns (uint8){
        uint8 minValue = 0;
        minValue -= _val;
        return minValue;
    }
}