// SPDX-License-Identifier: MIT
pragma solidity >=0.8.0 <0.9.0;

contract A{
    function foo() virtual public pure returns(string memory){
        return "A";
    }
    function bar() public pure virtual returns(string memory){
        return "A";
    }
    // Aqui podrian ir mas funciones
        function baz() public pure virtual returns(string memory){
        return "A";
    }

}

contract B is A{
    // sugerencia de lectura colocar el override antes del returns
    function foo()  public pure override returns(string memory){
        return "B";
    }
    function bar() override virtual public pure returns(string memory){
        return "B";
    }

}

contract C is B{
    function bar() override public pure returns(string memory){
        return "C";
    }

}