// SPDX-License-Identifier: MIT
pragma solidity >=0.8.0 <0.9.0;

contract E{
    // Creamos un evento
    event Log(string message); // 1)

    function foo() public virtual {
       emit Log("E.foo Original");
    }
    function bar() public virtual {
       emit Log("E.bar Original");
    }
}

contract F is E{
    function foo() public override virtual{
       emit Log("F.foo Sobreestrita en F");
       E.foo(); // Directa
    }

    function bar() public override virtual{
       emit Log("F.bar Sobreescrita en F");
       super.bar(); // A traves del super
    }
}

contract G is E{
    function foo() public override virtual {
       emit Log("G.foo Sobreestrita en G");
       E.foo(); // Directa
    }

    function bar() public override virtual{
       emit Log("G.bar Sobreescrita en G");
       super.bar(); // A traves del super
    }
}


contract H is F, G{
    function foo() public override(F, G) {
       E.foo(); // Directa
    }

    function bar() public override(F, G) {
       super.bar(); // A traves del super
    }
}