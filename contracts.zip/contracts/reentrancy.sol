// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8;

contract ReentrancyVulnerable{
    mapping(address => uint256) private balances;

    function deposit() external payable{
        balances[msg.sender] += msg.value;
    }

    function withdraw(uint256 _amount) external{
        require(_amount <= balances[msg.sender], "Insufficient balance");

        // Vulnerabilidad
        (bool success, ) = msg.sender.call{value: _amount}("");
        require(success, "Transfer failed."); // Reentrancy vulnerability)

        balances[msg.sender] -= _amount;
    }
}