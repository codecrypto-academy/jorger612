// SPDX-License-Identifier: MIT
pragma solidity >=0.8.0 <0.9.0;

contract CarreraOptimizado{
    uint public balance;

    mapping(address => uint256) public balances;
    mapping(address => bool) public isTransferring;

    function depositar() public payable{
        balances[msg.sender] += msg.value;
        balance += msg.value;
    }
    function retirar(uint256 _cantidad) public {

        require(balances[msg.sender] >= _cantidad, "Fondos insuficientes");
        require(!isTransferring[msg.sender], "Transaccion en progreso");
        
        isTransferring[msg.sender] = true;
        require(payable(msg.sender).send(_cantidad), "Error al realizar la transferencia");
        balances[msg.sender] -= _cantidad;

        isTransferring[msg.sender] = false;

    }
}