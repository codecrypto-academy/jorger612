// SPDX-License-Identifier: MIT
pragma solidity >=0.8.0 <0.9.0;

contract Counter{
    uint public count;

    function inc() external{
        count += 1;
    }

    function dec() external{
        count -= 1;
    }

}

/* el mismo programa en YUL
object "Counter" {
    code {
        datacopy(0, dataoffset("Counter_deployed"), datasize("Counter_deployed"))
        return(0, datasize("Counter_deployed"))
    }
    object "Counter_deployed" {
        code {
            // El selector de la función inc() es 0x371303c0
            let inc_selector := 0x371303c0
            // El selector de la función dec() es 0x05a7b63f
            let dec_selector := 0x05a7b63f

            // Lee los primeros 4 bytes del calldata para obtener el selector de la función
            let s := shr(224, calldataload(0))

            switch s
            case inc_selector {
                // Llama a la función 'inc'
                inc()
            }
            case dec_selector {
                // Llama a la función 'dec'
                dec()
            }
            default {
                // Si no coincide con ningún selector, revierte la transacción
                revert(0, 0)
            }

            function inc() {
                // Carga el valor actual del contador del storage (slot 0)
                let current_count := sload(0)
                // Incrementa el valor en 1
                current_count := add(current_count, 1)
                // Guarda el nuevo valor en el storage (slot 0)
                sstore(0, current_count)
            }

            function dec() {
                // Carga el valor actual del contador del storage (slot 0)
                let current_count := sload(0)
                // Decrementa el valor en 1
                current_count := sub(current_count, 1)
                // Guarda el nuevo valor en el storage (slot 0)
                sstore(0, current_count)
            }
        }
    }
}
*/