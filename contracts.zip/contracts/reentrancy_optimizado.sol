// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8;

contract ReentrancySafe{
    mapping(address => uint256) public balances;

    function deposit() external payable{
        balances[msg.sender] += msg.value;
    }

    function withdraw(uint256 _amount) external{
        require(balances[msg.sender] >= _amount, "Insufficient balance");

        require(payable(msg.sender).send(_amount), "Fallo en el envio");

        balances[msg.sender] -= _amount;

        
    }
}