// SPDX-License-Identifier: MIT
pragma solidity >=0.7.0 <0.9.0;


// Consumo de GAS 948 (solo solidity)
// Consumo de GAS 747 (usando YUL)
contract OptimizationYul{
    function sum(uint256 a, uint256 b) public pure returns(uint256){
        return a + b;
    }

    // Funcion Optimizada
    function sumYul(uint256 a, uint256 b) public pure returns(uint256 result){
          assembly{
             result := add(a, b)
          }  
    }    
}