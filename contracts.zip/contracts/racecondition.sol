// SPDX-License-Identifier: MIT
pragma solidity >=0.8.0 <0.9.0;

contract CarreraVulnerable{
    uint public balance;

    mapping(address => uint256) public balances;

    function depositar() public payable{
        balances[msg.sender] += msg.value;
        balance += msg.value;
    }
    function retirar(uint256 _cantidad) public {
        require(balances[msg.sender] >= _cantidad, "Fondos insuficientes");
        uint256 saldoAnterior = balances[msg.sender];
        balances[msg.sender] -= _cantidad;
        require(payable(msg.sender).send(_cantidad), "Error al realizar la transferencia");
        require(balances[msg.sender] == saldoAnterior, "Race Condition detectado");
    }
}