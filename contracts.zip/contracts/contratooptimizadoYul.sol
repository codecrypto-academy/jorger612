// SPDX-License-Identifier: MIT
pragma solidity >=0.7.0 <0.9.0;


// Consumo de GAS 948 (solo solidity)
// Consumo de GAS 747 (usando YUL)
contract ContratOptimizationYul{
    function sum(uint256 a, uint256 b) public pure returns(uint256){
        return a + b;
    }

    // Funcion Optimizada
    function sumYul(uint256 a, uint256 b) public pure returns(uint256 result){
          assembly{
             result := add(a, b)
          }  
    }    
    // funcion 1: solidity hash consumo 1055 gas
    function solidityHash(uint256 a, uint256 b) public pure {
        keccak256(abi.encodePacked(a,b));
    }
    // funcion hash yul consumo 637 gas
    function YulHash(uint256 a, uint256 b) public pure {
        assembly{
            mstore(0x00, a)
            mstore(0x20, b)
            let result := keccak256(0x00, 0x40)
        }
    }

    // Function 2: unchecked consumo 2019
    function UncheckedPlusI() public pure{
        uint j = 0;
        for(uint256 i; i < 10; ){
            j++;
            unchecked{
                ++i;
            }
        }
    }
    // function 2: uchecked yul consumo 850 gas
    function inlineAssemblyLoop() public pure{
        assembly{
            let j := 0
            for{let i := 0} lt(i, 10){i := add(i, 0x01)}{
                j := add(j, 0x01)
            }
        }
    }

    // operaciones matematicas consumo 813 gas
        function resta(uint256 a, uint256 b) public pure{
        uint256 c = a - b;
    }

    // Funcion Optimizada consumo 631 gas
    function restaAssemblyYul(uint256 a, uint256 b) public pure{
          assembly{
             let c := sub(a, b) // division div y multiplicacion mul

             // verifica si ocurre desbordamiento negativo undeflow
             if gt(c,a){
                mstore(0x00, "Undeflow")
                revert(0x00, 0x20)
             }
          }  
    }    

    // Funcion 4: Valores de almacenamiento Solidity consumo 5548 gas

    address owner = 0x5B38Da6a701c568545dCfcB03FcB875f56beddC4;  // Mia: 0xB7393AD6D79663D4d56aE0988cEe1d94e72F5608;

    function updateOwner(address newOwner) public {
        owner = newOwner;
    }  

    // Valores de almacenamiento con Yul consumo 5521 gas

    address public propietario = 0x5B38Da6a701c568545dCfcB03FcB875f56beddC4;  // Mia: 0xB7393AD6D79663D4d56aE0988cEe1d94e72F5608;

    function assemblyUpdateOwner(address nuevoPropietario) public {
        assembly {
            sstore(propietario.slot, nuevoPropietario)
        }
    }

}