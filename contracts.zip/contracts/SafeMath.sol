// SPDX-License-Identifier: MIT
pragma solidity >=0.8;

library SafeMath{
    function add(uint256 a, uint256 b) internal pure returns (uint256){
        uint256 c = a + b;
        require ( c >= a, "SafeMath: addition overflow");
        return c; // if a + b is less than a, then there is an overflow
    }

    function sub(uint256 a, uint256 b) internal pure returns (uint256){
        require(b <= a,"SafeMath substraction overflow");
        uint256 c = a - b;
        return c;
    }
}