// SPDX-License-Identifier: MIT
pragma solidity >=0.8.0 <0.9.0;

contract TestStorage{
    // Declaramos una variable de estado que sera almacenada en el storage
    uint public storeData;

    // Definimos una funcion para actualizar el valor almacenado en el storage
    function setValue(uint _newValue) external {
        storeData = _newValue;
    }

    function getValue() external view returns (uint) {
        return storeData;
    }
}

contract TestMemory{
    // Definimos una funcion externa que recibe una cadena de texto y devuelve su longitud
    function stringLength(string memory _str) external pure returns (uint){
        // Convertimos la cadena de calldata a memory
        bytes memory stringBytes = bytes(_str);
        // Devolvemos la longitud de la cadena en bytes
        return stringBytes.length;
    }
}

contract TestCalldata{
    // Definimos una funcion externa que reciba dos parametros
    function ProcessData(uint _value1, uint _value2) external pure returns(uint){
            // Accedemos a los datos en calldata y realizamos una operacion 
            uint result = _value1 + _value2;
            return result;
    }
}