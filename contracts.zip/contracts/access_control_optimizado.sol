// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8;


contract SecureAccessControl{
    address private owner;
    uint private secretNumber;

    constructor(){
        owner = msg.sender;
    }

    modifier onlyOwner() {
        require(msg.sender == owner, "Only the owner can call this function");
        _;
    } 

    function setSecretNumber(uint _newNumber) public onlyOwner {
         secretNumber = _newNumber;
    }

    function getSecretNumber() public view returns (uint){
        return  secretNumber;
    }


}