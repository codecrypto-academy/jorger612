// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8;

contract RamdomnessVulnerable{
    uint private seed;
    uint public randomNumber;

    constructor() {
        seed = block.timestamp;
    }

    function generarRandomNumber() public{
       randomNumber = uint(keccak256(abi.encodePacked(block.difficulty, block.timestamp, seed)));
    }

}