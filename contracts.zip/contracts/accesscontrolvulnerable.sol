// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8;


contract VulnerableAccessControl{
    address public owner;
    uint private secretNumber;

    constructor(){
        owner = msg.sender;
    }

    function setSecretNumber(uint _newNumber) public {
         secretNumber = _newNumber;
    }

    function getSecretNumber() public view returns (uint){
        return  secretNumber;
    }


}