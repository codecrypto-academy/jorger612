// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8;

interface RandomnessOracle{
    function getRandomNumber() external returns(uint);
}


contract RamdomnessOptimizado{
    uint public randomNumber;
    address private oracle;

    constructor(address _oracleAddress) {
        oracle = _oracleAddress;
    }

    function generarRandomNumber() public{
       require(oracle != address(0), "Oracle address not set");
       randomNumber = RandomnessOracle(oracle).getRandomNumber();
    }

}