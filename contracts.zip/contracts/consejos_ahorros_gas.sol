// SPDX-License-Identifier: MIT
pragma solidity >=0.8.0 <0.9.0;

contract GasRefactor{
    uint public total;

    function sumar(uint[] calldata nums) external{
        uint _total = total;
        uint len = nums.length;
        for(uint i = 0; i < len; ++i){
            uint num = nums[i];
            //bool esPar = nums[i] % 2 == 0;
            //bool esMenor99 = nums[i] < 99;
            if(num % 2 == 0 && num < 99){
                _total+=num;
                // [1,4,6,8, 99, 120]
                //transaction gas 51301 cost 28895 (con memory)
                // transaction gas 48470 cost 26286 (con calldata)
                // transaction gas 48043 cost 25859 ( con variable _total en memoria)
                 // transaction gas 47791 cost 25607 ( con corto circuito)
                 // transaction gas 47761 cost 25577 ( con incremento bucle ++i)
                 // transaction gas 47725 cost 25541 ( con cache de la longitud del array)
                 // transaction gas 47461 cost 25277 ( con elementos del array en memoria)

            }
        }
        total = _total;
    }
}

