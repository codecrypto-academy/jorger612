// SPDX-License-Identifier: MIT
pragma solidity >=0.8.0 <0.9.0;

contract UncheckedSend{
    mapping(address => uint256) public balances;

    function deposit() public payable {
        balances[msg.sender] += msg.value;
    }

    function withdraw(uint256 amount) public {
        require(balances[msg.sender] >= amount, "Saldo Insuficiente");

        // Vulnerabilidad
        payable(msg.sender).transfer(amount);
        balances[msg.sender] -= amount;

        // Asi se corrige la vulnerabilidad
        require(payable(msg.sender).send(amount),"Fallo el Envio");
        balances[msg.sender] -= amount;

        /* Recomendacion Gemini
        El código que compartiste no es un ejemplo de cómo corregir una vulnerabilidad, sino que es un ejemplo de cómo causar una vulnerabilidad y de cómo corregirla. La vulnerabilidad reside en la línea payable(msg.sender).transfer(amount);. Esta vulnerabilidad, conocida como la "llamada reentrante", se corrigió al cambiar transfer por send. Sin embargo, es importante que sepas que esto no es suficiente, ya que send tiene el mismo problema de la llamada reentrante.

El problema es que la llamada a la función transfer se ejecuta antes de que se actualice el saldo del usuario en el contrato. Por lo tanto, si el receptor del pago es otro contrato que tiene una función de "recibir" maliciosa, este contrato puede llamar de nuevo a la función de envío de fondos del contrato original antes de que el saldo del usuario haya sido actualizado, lo que le permitiría retirar fondos repetidamente. Esta es una vulnerabilidad de reentrada.

Para corregir el error, la actualización del saldo del usuario en el contrato (balances[msg.sender] -= amount;) debe ocurrir antes de que el contrato envíe el pago. Esta técnica se conoce como "Verificar, enviar, actualizar".
        function withdraw() public {
           uint amount = balances[msg.sender];
           require(amount > 0);
           // Correcto: se actualiza el saldo antes de enviar el pago
           balances[msg.sender] = 0;
           payable(msg.sender).transfer(amount);
        }*/

    }

}