// SPDX-License-Identifier: MIT
pragma solidity >=0.8.0 <0.9.0;

contract Inmutable{
    // Con inmutable 
    
    //address public immutable owner = msg.sender; //variable inmutable
    //43573 GAS
    address public owner;
    // Sin inmutable
    //address public immutable owner = msg.sender; //variable inmutable
   // 43950

   constructor(){
       owner = msg.sender;
   }

    uint public x;

    function foo() external{
        require(msg.sender == owner);
        x += 1;
    }
}
    

