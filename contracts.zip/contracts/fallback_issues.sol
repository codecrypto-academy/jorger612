// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8;

contract VulnerableFallback{
    mapping(address => uint256) private balances;

    fallback() external payable{
        balances[msg.sender] += msg.value;
    
        (bool success, ) = msg.sender.call{value: msg.value}("");
        require(success,"Transferencia Fallida");
    }

    function withdraw() public{
        uint256 amount = balances[msg.sender];
        require(amount > 0,"No hay fondos disponibles para retirar");

        balances[msg.sender] = 0;

        (bool success, ) = msg.sender.call{value: amount}("");
        require(success,"Transferencia Fallida");

    }

    receive() external payable{}
}