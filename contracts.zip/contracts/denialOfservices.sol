// SPDX-License-Identifier: MIT
pragma solidity >=0.8.0 <0.9.0;

contract DenialOfServiceVulnerable{
    function performDos(uint256 _iterations) pure public{
        for(uint256 i=0; i<_iterations;i++){
            uint256[] memory data = new uint256[](_iterations);
            for(uint256 j=0; j<_iterations;j++){
                data[j] = j;
            }



        }
    }
}

contract DenialOfServiceOptimizado{
    uint256 constant MAX_ITERATIONS = 100;

    function performDos(uint256 _iterations) pure public{
    
        require(_iterations <= MAX_ITERATIONS, "Max iterations reached");
    
        for(uint256 i=0; i<_iterations;i++){
            uint256[] memory data = new uint256[](_iterations);
    
            for(uint256 j=0; j<_iterations;j++){
                data[j] = j;
            }

        }
    }
}