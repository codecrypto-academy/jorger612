// SPDX-License-Identifier: MIT
pragma solidity >=0.8.0 <0.9.0;

contract TestVisibilidadFunciones{
    uint public numeroPublico;
    uint private numeroPrivado;
    uint internal numeroInterno;
    
    function setNumeroExternal(uint _nuevoNumero) external {
        numeroPublico = _nuevoNumero;
    }

    function setNumeroPrivado(uint _nuevoNumero) private {
        numeroPrivado = _nuevoNumero;
    }

    function setnumeroInterno(uint _nuevoNumero) internal {
        numeroInterno = _nuevoNumero;
    }

    function actualizarNumeros(uint _nuevoNumero) public {
        setNumeroPrivado(_nuevoNumero);
        setnumeroInterno(_nuevoNumero);
        
    }

    function getTestExternal() external view returns(uint){
        return numeroPublico;
    }

}

contract ContratoDerivado is TestVisibilidadFunciones{
   
   // Funcion publica que llame a la funcion internal del contrato base
   function actualizarNumeroDesdeDerivado(uint _nuevoNumero) public {
    setnumeroInterno(_nuevoNumero);
   }


}