// SPDX-License-Identifier: MIT
pragma solidity >=0.8.0 <0.9.0;

contract BucleWhile{

    // funcion 1: Nos permite en un while sumar los impares menores a 100
    function sumaImpares() public pure returns(uint256){
        uint suma = 0;
        uint contador = 1;
        while(contador <= 100){
            if(contador%2 != 0){
                suma += contador;
            }
            contador++;
        }
        return suma;
    }

    // funcion 2: Para sumar los primeros N numeros naturales
    function sumarNaturales(uint _n) public pure returns(uint){
        uint suma = 0;
        uint i = 1;

        while(i <= _n){
           suma += i;
           i++;
        }
        return suma;
    }  

    // Funcion 3: Contar digitos de un numero
    function contarDigitos(uint _numero) public pure returns(uint){
        uint contador = 0;

        while(_numero != 0){
               _numero /= 10;
               contador++;
        }
        return contador;
        
    } 

    // Funcion 4: Permite invertir un numero
    function invertirNumero(uint _numero) public pure returns(uint){

        uint invertido = 0;

        while(_numero != 0){
            invertido = invertido * 10 + _numero % 10;
            _numero /= 10;
        }
        return invertido;
    } 

}