// SPDX-License-Identifier: MIT
pragma solidity >=0.8.0 <0.9.0;


contract CostlyOperationsVulnerable{
    uint256 constant public MAX_ITERATIONS = 1600;

    function performCostlyOperation() pure external returns(uint256 result){
        result = sumNumbers(MAX_ITERATIONS);
    }

    function sumNumbers(uint256 n) internal pure returns (uint256) {
        return (n * (n + 1)) / 2;
    }

}