// SPDX-License-Identifier: MIT
pragma solidity >=0.8.0 <0.9.0;


contract Eventos {
    event DepositoTest(string indexed nombre);
    event DepositoTest2(string indexed nombre, uint cantidad);
    event DepositoTest3(string nombre, uint, address indexed, bytes32);
    
    // Funcion Evento 1
    function depositar(string memory _nombre) public {
        // code
        emit DepositoTest(_nombre);
    }

    // Funcion Evento 2
    function depositar2(string memory _nombre, uint _cantidad) public {
        // code
        emit DepositoTest2(_nombre, _cantidad);
    }

    // funcion evento 3
    function depositar3(string memory _nombre, uint _edad) public {
        // code
        bytes32 hashId = keccak256(abi.encodePacked(_nombre, _edad, msg.sender));
        emit DepositoTest3(_nombre, _edad, msg.sender,  hashId);
    }
}