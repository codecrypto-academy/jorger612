// SPDX-License-Identifier: MIT
pragma solidity >=0.8.0 <0.9.0;

contract BucleFor{
    // Funcion que suma los primeros 100 numeros naturales
    function Suma100(uint _numero) public pure returns(uint){
        uint suma = 0;
        for (uint i = _numero; i < (_numero + 100); i++){
            suma += i;
        }
        return suma;
    }

    // Funcion 2
    address[] private direcciones;

    function asociar() public {
        direcciones.push(msg.sender);
    } 

    function comprobarAsociacion() public view returns(bool estado, address direccion){
          for(uint i = 0; i < direcciones.length; i++){
              if (direcciones[i] == msg.sender){
                  estado = true;
                  direccion = direcciones[i];
                  break;
              }
          }
          if(estado == false){
              direccion = address(0);
              return(false, direccion);
          }else{
              return(true, direccion);
          }
    }

}