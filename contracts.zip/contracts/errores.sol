// SPDX-License-Identifier: MIT
pragma solidity >=0.8.0 <0.9.0;

contract Error{

    uint public num = 123;


    function testRequire(uint _i) public pure{
        require(_i <= 10, "i > 10");
        // Codigo Adicional
    }

    function testRevert(uint _i) public pure{
        if(_i > 1){
            if(_i > 2){
              if(_i > 10){
                 revert("i > 10");
              }
            }            
        } 
    }

    function testAssert() public view{
        assert(num == 12);
    }

    error MyError(address caller, uint i); // Definimos un error personalizado

    function testErrorPersonalizado(uint _i) public view{
              if(_i > 10){
                 revert MyError(msg.sender, _i);
              }
    }

}