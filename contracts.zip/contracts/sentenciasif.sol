// SPDX-License-Identifier: MIT
pragma solidity >=0.8.0 <0.9.0;

contract SentenciaIf{
    // Numero ganador
    function numeroGanador(uint _numero) public pure returns(string memory){
        if(_numero==7){
           return "Has Ganado";
        }else{
           return "Perdiste !!";
        }
    }

    // Valor Absoluto
    function valorAbsoluto(int _numero) public pure returns(uint){
        return uint(_numero < 0 ? - _numero : _numero);
    }

    // Funcion que devuelve true si el numero introducido es par y tiene 3 cifras
    function esParDTres(uint _numero) public pure returns(bool){
        return (_numero % 2 == 0 && _numero >= 100 && _numero <= 999);
    }

    // Funcion para votar
    function  votar(string memory _candidato) public pure returns(string memory){
        if(esIgual(_candidato, "Ronaldinho")){
            return "Has votado a Ronaldinho";
        }else if(esIgual(_candidato, "Messi")){
            return "Has votado a Messi";
        } else if(esIgual(_candidato, "Cristiano")){
            return "Has votado a Cristiano";
        }else{
            return "Voto no Valido";
        }
    }

    function esIgual(string memory _a, string memory _b) internal pure returns(bool) {
        return keccak256(abi.encodePacked(_a)) == keccak256(abi.encodePacked(_b));
    }

}