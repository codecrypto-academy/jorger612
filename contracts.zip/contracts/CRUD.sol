// SPDX-License-Identifier: MIT
pragma solidity >=0.7.0 <0.9.0;

contract userCrud{
    struct User {
        uint id;
        string name;
        uint age;
        bool isActive;
    }

    mapping(uint256 => User) private users;
    uint256 private nextId;

    event UserCreated(uint256 id, string name, uint256 age);
    event UserUpdated(uint256 id, string name, uint256 age);
    event UserDeleted(uint256 id);

    // Crear usuarios
    function createUser(string memory _name, uint256 _age) public {
        nextId++;
        users[nextId] = User(nextId, _name, _age, true);
        emit UserCreated(nextId, _name, _age);
    }

    // Leer usuario

    function readUser(uint256 _id) public view returns (uint256, string memory, uint256, bool) {
          require (_id <= nextId, "ID no valido");
          require(users[_id].isActive,"El Usuario Esta Inactivo");
          User memory user = users[_id];
          return (user.id, user.name, user.age, user.isActive);
    } 

    // Actualizar usuario
    function updateUser(uint256 _id, string memory _name, uint256 _age) public {
        require(_id <= nextId, "ID no valido");
        require(users[_id].isActive,"El Usuario Esta Inactivo");
        User storage user = users[_id];
        user.name = _name;
        user.age = _age;
        emit UserUpdated(_id, _name, _age);
    }   

    // Eliminar usuario
    function deleteUser(uint256 _id) public {
        require(_id <= nextId, "ID no valido");
        require(users[_id].isActive,"El Usuario Esta Inactivo");
        users[_id].isActive = false;
        emit UserDeleted(_id);
    }

    // Traer todos los registros Activos
    function getAllActiveUsers() public view returns (User[] memory) {
        User[] memory activeUsers = new User[](nextId);
        uint256 count = 0;
        for (uint256 i = 1; i <= nextId; i++) {
            if (users[i].isActive) {
                activeUsers[count] = users[i];
                count++;
            }
        }
        return activeUsers;
    }

}


// Optimizado con YUL
/*

contract userCrudOptimizado {
    struct User {
        uint id;
        string name;
        uint age;
        bool isActive;
    }

    mapping(uint256 => User) private users;
    uint256 private nextId;

    event UserCreated(uint256 id, string name, uint256 age);
    event UserUpdated(uint256 id, string name, uint256 age);
    event UserDeleted(uint256 id);

    // Crear usuarios
    function createUser(string memory _name, uint256 _age) public {
        nextId++;
        users[nextId] = User(nextId, _name, _age, true);
        emit UserCreated(nextId, _name, _age);
    }

    // Leer usuario (Optimizado con Yul)
    function readUser(uint256 _id) public view returns (uint256, string memory, uint256, bool) {
        // En un contrato de este tamaño, usar Yul para readUser no es estrictamente necesario,
        // pero sirve como un ejemplo educativo. El compilador de Solidity 0.8.x es muy eficiente.
        require(_id <= nextId, "ID no valido");
        User storage user = users[_id];
        require(user.isActive, "El Usuario Esta Inactivo");

        uint256 id;
        uint256 age;
        bool isActive;
        string memory name;

        // Yul para optimizar la lectura de los valores del struct de la memoria
        assembly {
            // Cargar el struct del almacenamiento
            let userSlot := sload(users.slot) // Obtener el slot base del mapping
            let userAddress := add(userSlot, _id) // Calcular la dirección del struct
            let userData := sload(userAddress)

            // Cargar valores del struct de la ranura de almacenamiento
            id := and(user.id, 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff) // Cargar el id
            age := and(user.age, 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff) // Cargar la edad
            isActive := and(user.isActive, 1) // Cargar el booleano

            // Para la cadena de texto, debemos manejar su desplazamiento de almacenamiento
            let nameSlot := add(userAddress, 1) // El nombre está en la siguiente ranura
            let nameData := sload(nameSlot)
            name := sload(nameData)
        }

        return (id, name, age, isActive);
    }

    // Actualizar usuario
    function updateUser(uint256 _id, string memory _name, uint256 _age) public {
        require(_id <= nextId, "ID no valido");
        require(users[_id].isActive, "El Usuario Esta Inactivo");
        User storage user = users[_id];
        user.name = _name;
        user.age = _age;
        emit UserUpdated(_id, _name, _age);
    }

    // Eliminar usuario
    function deleteUser(uint256 _id) public {
        require(_id <= nextId, "ID no valido");
        require(users[_id].isActive, "El Usuario Esta Inactivo");
        users[_id].isActive = false;
        emit UserDeleted(_id);
    }

    // Traer todos los registros activos (Optimizado)
    function getAllActiveUsers() public view returns (User[] memory) {
        uint256 totalUsers = nextId;
        uint256 activeCount = 0;
        User[] memory tempUsers = new User[](totalUsers);

        for (uint i = 1; i <= totalUsers; i++) {
            if (users[i].isActive) {
                tempUsers[activeCount] = users[i];
                activeCount++;
            }
        }

        // Crear un array del tamaño exacto para evitar espacios vacíos
        User[] memory activeUsers = new User[](activeCount);
        assembly {
            let activeUsersPtr := add(activeUsers, 0x20) // Puntero al inicio de los datos
            let tempUsersPtr := add(tempUsers, 0x20)

            // Copiar los datos de tempUsers a activeUsers
            for { let i := 0 } lt(i, mul(activeCount, 0x20)) { i := add(i, 0x20) } {
                mstore(add(activeUsersPtr, i), mload(add(tempUsersPtr, i)))
            }
        }
        return activeUsers;
    }
}
*/