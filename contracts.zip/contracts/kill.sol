// SPDX-License-Identifier: MIT
pragma solidity >=0.8.0 <0.9.0;


contract kill{

    constructor() payable {}

        function killContracts() external {
            selfdestruct(payable(msg.sender));
        } 

        function testContract() external pure returns(string memory){
              return "Estoy Funcionando"; 
        }   

}